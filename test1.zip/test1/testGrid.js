function createGridGeometry(size, subdiv) {
  var geometry = new THREE.Geometry();

  // Layout de vertices
  var step = subdiv + 1; // Décalage d'indice
  for (var i = 0.; i < step; i++) {
    for (var j = 0.; j < step; j++) {
      geometry.vertices.push(
        new THREE.Vector3(i/step * size - size/2., j/step * size - size/2., 0)
      );
    }
  }

  // Création des faces
  for (var i = 0; i < subdiv; i++) {
    for (var j = 0; j < subdiv; j++) {

      var k = function(x, y, s) {
        return x + y * s;
      }

      geometry.faces.push(
        new THREE.Face3(
          k(i, j, step),
          k(i+1, j, step),
          k(i, j+1, step)
        ),
        new THREE.Face3(
          k(i+1, j+1, step),
          k(i+1, j, step),
          k(i, j+1, step)
        )
      );
    }
  }

  geometry.computeBoundingBox();

  return geometry;
}
