var renderer, scene, camera, mesh, controls;

init();
animate();

function init(){

    // on initialise le moteur de rendu
    renderer = new THREE.WebGLRenderer({alpha: true});

    renderer.setSize( window.innerWidth, window.innerHeight );
    document.getElementById('container').appendChild(renderer.domElement);

    // on initialise la scène
    scene = new THREE.Scene();

    // on initialise la camera que l’on place ensuite sur la scène
    camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 1, 1000 );
    camera.position.set(0, 0, 10);
    scene.add(camera);

    var geometry = createGridGeometry( 8, 21 );
    var material = new THREE.MeshBasicMaterial( { color: 0x00ff00, wireframe: true } );
    mesh = new THREE.Mesh( geometry, material );
    scene.add( mesh );

    controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.25;
    controls.enableZoom = true;

    mesh.rotation.x -= 3.14/2;
}

function wave(x, y, period, speed, intensity) {
  var geometry = mesh.geometry;
  for (var i in geometry.vertices) {
    var vertice = geometry.vertices[i];
    var d = Math.sqrt(Math.pow(vertice.x - x, 2) + Math.pow(vertice.y - y, 2));
    vertice.z = Math.sin(Date.now()/1000 * -speed + d * 1/period) * intensity;
  }

  geometry.verticesNeedUpdate = true;
}

function animate(){
    requestAnimationFrame( animate );
    controls.update();
    wave(0, 0, 0.2, 5, 0.2);
    renderer.render( scene, camera );
}
